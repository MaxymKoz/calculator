import java.awt.*;
import java.awt.event.*;
import java.util.Scanner;
import javax.swing.*;

public class Iterface extends JFrame {
    private JButton button = new JButton("Знайти Рішення");
    private JTextField inputA= new JTextField("", 5);
    private JTextField inputB = new JTextField("", 5);
    private JTextField inputC = new JTextField("", 5);
    private JLabel labelA = new JLabel("Задайте значення а: ");
    private JLabel labelB = new JLabel("Задайте значення b: ");
    private JLabel labelC= new JLabel("Задайте значення c: ");
    private JCheckBox check = new JCheckBox("Тест на робота", false);





    public Iterface (){
        super("Калькулятор простих квадратних рівнянь");
        this.setBounds(100,100,600,200);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        Container container = this.getContentPane();
        container.setLayout(new GridLayout(4,2,5,5));
        container.add(labelA);
        container.add(inputA);
        container.add(labelB);
        container.add(inputB);
        container.add(labelC);
        container.add(inputC);
        ButtonGroup group = new ButtonGroup();
        container.add(check);
        button.addActionListener(new ButtonEventListener ());
        container.add(button);

    }
    class ButtonEventListener implements ActionListener{

        public void actionPerformed (ActionEvent e){
            // a*x*2+b*x+c=0
            int a;
            int b;
            int c;
            a = Integer.parseInt(inputA.getText());
            b = Integer.parseInt(inputB.getText());
            c = Integer.parseInt(inputC.getText());
            double x1=0, x2=0;

            double Discriminant = b*b-4*a*c; //формула Дискримінанта

            if (Discriminant == 0) { //Якщо Дикср. = 0
               x1 += (-b) / (2 * a);
               x2=x1;
            }else if(Discriminant > 0 ){
                x1 += (-b+Math.sqrt(Discriminant))/(2*a);
                x2 += (-b-Math.sqrt(Discriminant))/(2*a);
            }else { //Якщо Дикср. < 0
                System.out.println("err");
            }

            String message = "";
            message += "Розрахунки закінчені!\n";
            message += "x1 = "+ x1 + "\n";
            message += "x2 = "+ x2 + "\n";
            message += ((check.isSelected())? "Ви Робот(": "Ви не робот!");
            JOptionPane.showMessageDialog(null, message, "Рішення", JOptionPane.PLAIN_MESSAGE );
        }

    }
}
