
import java.util.Scanner;
class Main {

    public static void main(String[] args){
          Iterface app = new Iterface();
          app.setVisible(true);

    }
    //Scanner scanner = new Scanner(System.in);
    //        // a*x*2+b*x+c=0
    //        double a,b,c;
    //        double x1, x2;
    //        System.out.println("Задайте a:");
    //        a = scanner.nextDouble();
    //        System.out.println("Задайте b:");
    //        b = scanner.nextDouble();
    //        System.out.println("Задайте c:");
    //        c = scanner.nextDouble();
    //
    //        double Discriminant = b*b-4*(a*c); //формула Дискрімінанта
    //        if (Discriminant == 0 ){ //Якщо Дикср. = 0
    //            x1 = (-b)/(2*a);
    //            System.out.printf("x1 = x2 = %s", x1); // показуємо результат
    //
    //        } else if (Discriminant > 0 ) { //Якщо Дикср. > 0
    //            x1 = (-b+Math.sqrt(Discriminant))/(2*a);
    //            x2 = (-b-Math.sqrt(Discriminant))/(2*a);
    //            System.out.printf("x1 = %s, x2 = %s", x1, x2);// показуємо результат
    //
    //        }else { //Якщо Дикср. < 0
    //            System.out.println("Цілого рішення немає,бо Дикскр. < 0"); // показуємо результат
    //        }
}
